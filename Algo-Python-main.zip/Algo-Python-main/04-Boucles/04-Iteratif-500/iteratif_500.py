"""
Exercice 4 : Affichage itératif des nombres jusqu'à 500 avec while.
"""

def afficher_jusqu_a_500():
    pass

def afficher_jusqu_a_limite(limite):
    pass



if __name__ == "__main__":
    print("=== Affichage des nombres de 1 à 20 ===")
    afficher_jusqu_a_limite(20)
    

