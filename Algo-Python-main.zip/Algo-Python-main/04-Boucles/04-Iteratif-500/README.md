# Exercice 4 : Affichage itératif jusqu'à 500

## Énoncé

Utiliser l'itérativité pour afficher tous les nombres tant qu'on ne dépasse pas 500.
