# Exercice 2 : Affichage de fruits avec boucle for

## Énoncé

Créez une liste de cinq fruits et utilisez une boucle for pour les afficher un par un.
