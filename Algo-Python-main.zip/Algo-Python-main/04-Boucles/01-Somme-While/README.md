# Exercice 1 : Somme avec boucle while

## Énoncé

Écrivez une boucle while qui calcule la somme des nombres de 1 à 100.
