# Exercice 3 : Affichage des nombres de 1 à N

## Énoncé

Écrivez une boucle for qui affiche tous les nombres entre 1 et N compris.
