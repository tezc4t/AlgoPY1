Stack: Reverse String ( \*\* Interview Question)
The reverse_string function takes a single parameter string, which is the string you want to reverse.

Return a new string with the letters in reverse order.

This will use the Stack class we created in the last three coding exercises:
