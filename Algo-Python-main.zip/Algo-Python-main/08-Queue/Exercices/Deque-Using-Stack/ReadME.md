Queue Using Stacks: Dequeue ( \*\* Interview Question)
You have been tasked with implementing a queue data structure using two stacks in Python, and you need to write the dequeue method.

The dequeue method should remove and return the first element in the queue.

NOTE: I have added some diagrams under the Hints tab that show how this works, step-by-step.
