"""
Écrire une fonction qui parcourt et affiche tous les éléments d'une liste.
"""

def print_items(n):
    pass
        

print_items(10)
