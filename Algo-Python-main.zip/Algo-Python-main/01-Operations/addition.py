"""
Module contenant les opérations arithmétiques de base. <---- Docstring
"""

# addition

# quotient

# modulo
