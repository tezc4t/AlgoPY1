# Algo-Python

Version actuelle: Python 3 (3.10)

Download
Windows: https://www.python.org/downloads/windows/
MacOS: https://www.python.org/downloads/macos/
homebrew: brew install python
Linux: command line
sudo apt-get updatebrew install python
sudo apt-get install python3.10
VS Code https://code.visualstudio.com/docs/setup/setup-overview

Vérifier l’installation: python --version
