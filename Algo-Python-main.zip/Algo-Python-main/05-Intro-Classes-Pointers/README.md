✅ Qu’est-ce qu’une classe en Python ?

Une classe en Python est un modèle (ou plan de construction) qui sert à créer des objets.
Elle regroupe :

des données → appelées attributs

des comportements → appelés méthodes

Les objets créés à partir d’une classe possèdent la même structure et les mêmes fonctionnalités définies dans cette classe.
